package io.github.nandandesai.pico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookShelfBaseServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
