package io.github.nandandesai.pico.dto.responses;

public enum ResponseType {
    SUCCESS, LOGIN_FAILED, UNAUTHORIZED, VALIDATION_ERROR, EXCEPTION,
    RESOURCE_NOT_FOUND, DUPLICATE_ENTITY
}
