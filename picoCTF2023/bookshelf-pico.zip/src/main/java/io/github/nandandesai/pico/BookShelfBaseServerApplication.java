package io.github.nandandesai.pico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookShelfBaseServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookShelfBaseServerApplication.class, args);
	}

}
