INSERT INTO roles VALUES ('Free', 1);
INSERT INTO roles VALUES ('Basic', 2);
INSERT INTO roles VALUES ('Premium', 3);
INSERT INTO roles VALUES ('Admin', 4);
