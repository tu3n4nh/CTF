<?php
$flag =
?>
can you see $flag?%