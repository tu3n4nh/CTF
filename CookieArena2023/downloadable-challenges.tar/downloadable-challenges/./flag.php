<?php
    echo "CHH{Th15_Is_A_d0WnLoAd_ChA1lENGe}";
    
    
    echo "Remember! The flag is FORMAT:CHH{***}";
    echo "If the thread asks for CHH{SHA1(***)}, CHH{MD5(***)}, CHH{BASE64(***)} then you must encrypt the string with SHA1, MD5, BASE64 before submitting";


    echo "Hãy ghi nhớ! Flag luôn có định dạng là CHH{***}, bao gồm cả CHH{ và dấu } ở phía cuối";
    echo "Nếu đề bài đưa ra yêu cầu CHH{SHA1(***)}, CHH{MD5(***)}, CHH{BASE64(***)} thì bạn phải mã hóa chuỗi bằng SHA1, MD5, BASE64 trước khi submit";